## Packages
recharts | For the points history and leaderboard charts
framer-motion | For smooth page transitions and animations
lucide-react | For beautiful iconography (already in stack but confirming usage)
date-fns | For formatting timestamps in reports and events
clsx | For conditional class names
tailwind-merge | For merging tailwind classes

## Notes
Authentication uses Replit Auth via /api/login and /api/logout
The app requires geolocation access for reporting issues
Images for reports will use placeholder URLs for now until file upload is fully implemented
