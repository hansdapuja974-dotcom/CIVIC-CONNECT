import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Navigation } from "@/components/Navigation";
import { useAuth } from "@/hooks/use-auth";

import Landing from "@/pages/Landing";
import Dashboard from "@/pages/Dashboard";
import ReportIssue from "@/pages/ReportIssue";
import Leaderboard from "@/pages/Leaderboard";
import Rewards from "@/pages/Rewards";
import Events from "@/pages/Events";
import NotFound from "@/pages/not-found";

function PrivateRoute({ component: Component }: { component: React.ComponentType }) {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) return null;

  if (!isAuthenticated) {
    window.location.href = "/";
    return null;
  }

  return <Component />;
}

function Router() {
  const [location] = useLocation();
  const isLanding = location === "/";

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {!isLanding && <Navigation />}
      <main className={!isLanding ? "container mx-auto px-4 py-8 flex-1" : "flex-1"}>
        <Switch>
          <Route path="/" component={Landing} />
          <Route path="/dashboard">
            <PrivateRoute component={Dashboard} />
          </Route>
          <Route path="/report">
            <PrivateRoute component={ReportIssue} />
          </Route>
          <Route path="/leaderboard">
            <PrivateRoute component={Leaderboard} />
          </Route>
          <Route path="/rewards">
            <PrivateRoute component={Rewards} />
          </Route>
          <Route path="/events">
            <PrivateRoute component={Events} />
          </Route>
          <Route component={NotFound} />
        </Switch>
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
