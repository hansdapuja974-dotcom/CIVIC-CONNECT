import { Link, useLocation } from "wouter";
import { LayoutDashboard, MapPin, Trophy, Gift, Calendar, Menu, X, LogOut, User } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useUserStats } from "@/hooks/use-civic-data";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function Navigation() {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const { data: stats } = useUserStats();
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/report", label: "Report Issue", icon: MapPin },
    { href: "/leaderboard", label: "Leaderboard", icon: Trophy },
    { href: "/rewards", label: "Rewards", icon: Gift },
    { href: "/events", label: "Events", icon: Calendar },
  ];

  const handleLogout = () => {
    logout();
  };

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-md">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-primary to-secondary flex items-center justify-center text-white font-bold text-lg">
            C
          </div>
          <span className="font-display font-bold text-xl tracking-tight">CivicConnect</span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-1">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <div
                className={cn(
                  "px-4 py-2 rounded-full text-sm font-medium transition-colors hover:bg-muted cursor-pointer flex items-center gap-2",
                  location === item.href
                    ? "bg-primary/10 text-primary hover:bg-primary/20"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                <item.icon className="w-4 h-4" />
                {item.label}
              </div>
            </Link>
          ))}
        </div>

        {/* User Profile / Mobile Menu */}
        <div className="flex items-center gap-4">
          <div className="hidden md:flex items-center gap-4">
            {stats && (
              <div className="bg-secondary/10 px-3 py-1 rounded-full border border-secondary/20">
                <span className="text-sm font-bold text-secondary-foreground text-primary">{stats.points} pts</span>
              </div>
            )}
            
            <div className="flex items-center gap-3 pl-4 border-l border-border">
              <div className="text-right hidden lg:block">
                <p className="text-sm font-medium leading-none">{user?.firstName || 'Citizen'}</p>
                <p className="text-xs text-muted-foreground">Level {Math.floor((stats?.points || 0) / 100) + 1}</p>
              </div>
              <Avatar className="h-9 w-9 border-2 border-background ring-2 ring-border/50">
                <AvatarImage src={user?.profileImageUrl || undefined} />
                <AvatarFallback className="bg-primary/10 text-primary font-bold">
                  {user?.firstName?.[0] || 'U'}
                </AvatarFallback>
              </Avatar>
              <Button variant="ghost" size="icon" onClick={handleLogout} className="text-muted-foreground hover:text-destructive">
                <LogOut className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Mobile Menu Trigger */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[400px]">
              <div className="flex flex-col gap-6 mt-6">
                <div className="flex items-center gap-4 pb-6 border-b border-border">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={user?.profileImageUrl || undefined} />
                    <AvatarFallback>{user?.firstName?.[0] || 'U'}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{user?.firstName} {user?.lastName}</p>
                    <p className="text-sm text-muted-foreground">{stats?.points || 0} Civic Points</p>
                  </div>
                </div>
                
                <div className="flex flex-col gap-2">
                  {navItems.map((item) => (
                    <Link key={item.href} href={item.href}>
                      <div
                        onClick={() => setIsOpen(false)}
                        className={cn(
                          "px-4 py-3 rounded-lg text-sm font-medium transition-colors flex items-center gap-3 cursor-pointer",
                          location === item.href
                            ? "bg-primary/10 text-primary"
                            : "text-muted-foreground hover:bg-muted hover:text-foreground"
                        )}
                      >
                        <item.icon className="w-5 h-5" />
                        {item.label}
                      </div>
                    </Link>
                  ))}
                </div>

                <div className="mt-auto border-t border-border pt-6">
                  <Button variant="destructive" className="w-full justify-start gap-3" onClick={handleLogout}>
                    <LogOut className="w-4 h-4" />
                    Sign Out
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
