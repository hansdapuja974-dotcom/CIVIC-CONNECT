import { Report } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatDistanceToNow } from "date-fns";
import { CheckCircle2, Clock, AlertCircle, XCircle } from "lucide-react";

interface ReportCardProps {
  report: Report;
}

export function ReportCard({ report }: ReportCardProps) {
  const getStatusConfig = (status: string) => {
    switch (status) {
      case "resolved":
        return { color: "bg-green-500/10 text-green-700 border-green-200", icon: CheckCircle2, label: "Resolved" };
      case "in_progress":
        return { color: "bg-blue-500/10 text-blue-700 border-blue-200", icon: Clock, label: "In Progress" };
      case "rejected":
        return { color: "bg-red-500/10 text-red-700 border-red-200", icon: XCircle, label: "Rejected" };
      default:
        return { color: "bg-yellow-500/10 text-yellow-700 border-yellow-200", icon: AlertCircle, label: "Submitted" };
    }
  };

  const statusConfig = getStatusConfig(report.status);
  const StatusIcon = statusConfig.icon;

  return (
    <Card className="overflow-hidden card-hover group border-border/60">
      <div className="relative h-48 bg-muted/50 overflow-hidden">
        {report.mediaUrl ? (
          <img 
            src={report.mediaUrl} 
            alt={report.title} 
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-muted text-muted-foreground">
            No Image
          </div>
        )}
        <div className="absolute top-3 right-3">
          <Badge className={`border ${statusConfig.color} backdrop-blur-sm shadow-sm`}>
            <StatusIcon className="w-3 h-3 mr-1.5" />
            {statusConfig.label}
          </Badge>
        </div>
      </div>
      
      <div className="p-5">
        <h3 className="font-display font-bold text-lg leading-tight mb-2 truncate">
          {report.title}
        </h3>
        <p className="text-muted-foreground text-sm line-clamp-2 mb-4">
          {report.description}
        </p>
        
        <div className="flex items-center justify-between pt-4 border-t border-border/50">
          <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-tight">
            📅 {formatDistanceToNow(new Date(report.createdAt), { addSuffix: true })}
          </span>
          {report.aiVerificationStatus === 'verified' && (
            <div className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-primary bg-primary/5 px-2 py-1 rounded-md">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary/50 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
              </span>
              Verified
            </div>
          )}
        </div>

      </div>
    </Card>
  );
}
