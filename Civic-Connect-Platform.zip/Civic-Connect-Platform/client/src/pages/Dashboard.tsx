import { useAuth } from "@/hooks/use-auth";
import { useReports, useUserStats, useEvents } from "@/hooks/use-civic-data";
import { ReportCard } from "@/components/ReportCard";
import { Button } from "@/components/ui/button";
import { Loader2, Plus, MapPin, Trophy, ArrowRight } from "lucide-react";
import { Link } from "wouter";
import { format } from "date-fns";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: stats, isLoading: statsLoading } = useUserStats();
  const { data: reports, isLoading: reportsLoading } = useReports({ userId: user?.id });
  const { data: events } = useEvents();

  if (statsLoading || reportsLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  // Calculate recent activity
  const recentReports = reports?.slice(0, 3) || [];
  const upcomingEvent = events?.[0];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Welcome Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <h1 className="font-display font-bold text-3xl md:text-4xl mb-2">
            Welcome back, {user?.firstName}
          </h1>
          <p className="text-muted-foreground">
            You've made a real impact in your community this week.
          </p>
        </div>
        <Link href="/report">
          <Button size="lg" className="rounded-xl shadow-lg shadow-primary/20 hover:shadow-primary/30 transition-all active:scale-95">
            <Plus className="w-5 h-5 mr-2" />
            Submit New Report
          </Button>
        </Link>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20 rounded-2xl p-6 hover:shadow-md transition-all">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-bold text-primary/80 uppercase tracking-widest">Community Impact</span>
            <Trophy className="w-5 h-5 text-primary" />
          </div>
          <div className="text-4xl font-display font-bold text-primary mb-1">{stats?.points || 0} <span className="text-sm font-medium opacity-70 tracking-normal">pts</span></div>
          <p className="text-xs font-medium text-muted-foreground bg-primary/5 inline-block px-2 py-0.5 rounded-full">Global Rank #{stats?.rank || '-'}</p>
        </div>

        <div className="bg-card border border-border rounded-2xl p-6 shadow-sm hover:shadow-md transition-all">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Active Reports</span>
            <MapPin className="w-5 h-5 text-muted-foreground" />
          </div>
          <div className="text-4xl font-display font-bold text-foreground mb-1">{stats?.reportsCount || 0}</div>
          <p className="text-sm text-muted-foreground flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-green-500 animate-pulse" />
            Verified contributions
          </p>
        </div>

        <div className="bg-card border border-border rounded-2xl p-6 shadow-sm flex flex-col justify-center items-center text-center space-y-2 group cursor-pointer hover:border-primary/50 transition-all hover:shadow-md">
           <Link href="/rewards">
            <div className="w-full h-full flex flex-col items-center justify-center">
             <span className="text-sm font-bold text-muted-foreground group-hover:text-primary transition-colors">🎁 Redeem Rewards</span>
             <span className="text-xs font-medium text-primary mt-1 opacity-0 group-hover:opacity-100 transition-all transform translate-y-1 group-hover:translate-y-0">Visit Marketplace →</span>
            </div>
           </Link>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="grid lg:grid-cols-3 gap-8">
        
        {/* Recent Reports Column */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="font-display font-bold text-xl flex items-center gap-2">
              Recent Activity
              <span className="h-2 w-2 rounded-full bg-primary" />
            </h2>
            <Link href="/reports">
               <span className="text-sm font-semibold text-primary hover:underline cursor-pointer">View History</span>
            </Link>
          </div>

          {recentReports.length > 0 ? (
            <div className="grid sm:grid-cols-2 gap-4">
              {recentReports.map(report => (
                <ReportCard key={report.id} report={report} />
              ))}
            </div>
          ) : (
            <div className="bg-muted/10 border border-dashed border-border/60 rounded-2xl p-12 text-center group hover:bg-muted/20 transition-colors">
              <div className="w-16 h-16 bg-muted/30 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <MapPin className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="font-bold text-lg mb-1">Your Feed is Quiet</h3>
              <p className="text-sm text-muted-foreground mb-6 max-w-[240px] mx-auto">Help make your neighborhood better. Be the first to report an issue!</p>
              <Link href="/report">
                <Button variant="outline" className="rounded-xl border-dashed">
                  <Plus className="w-4 h-4 mr-2" />
                  Start Reporting
                </Button>
              </Link>
            </div>
          )}
        </div>

        {/* Sidebar / Events */}
        <div className="space-y-6">
          <h2 className="font-display font-bold text-xl flex items-center gap-2">
            Local Drives
            <span className="text-xs font-normal bg-blue-500/10 text-blue-600 px-2 py-0.5 rounded-full">Community</span>
          </h2>
          
          {upcomingEvent ? (
            <div className="bg-card border border-border rounded-2xl p-5 shadow-sm hover:shadow-md transition-all group">
              <div className="flex items-start justify-between mb-4">
                <div className="bg-blue-600 text-white px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-tighter">
                  {format(new Date(upcomingEvent.startTime), "MMM d")}
                </div>
                <div className="bg-muted text-muted-foreground px-2 py-1 rounded-md text-[10px] font-bold">
                  {format(new Date(upcomingEvent.startTime), "h:mm a")}
                </div>
              </div>
              <h3 className="font-bold text-lg mb-2 group-hover:text-primary transition-colors">{upcomingEvent.title}</h3>
              <p className="text-sm text-muted-foreground mb-4 line-clamp-2 leading-relaxed">
                {upcomingEvent.description}
              </p>
              <div className="flex items-center text-xs font-medium text-muted-foreground mb-4 bg-muted/30 p-2 rounded-lg">
                <MapPin className="w-3.5 h-3.5 mr-2 text-primary" />
                {upcomingEvent.location}
              </div>
              <Link href="/events">
                 <Button className="w-full font-bold shadow-sm" variant="secondary">Count Me In</Button>
              </Link>
            </div>
          ) : (
             <div className="bg-muted/10 border border-border/40 rounded-2xl p-6 text-center">
               <p className="text-sm font-medium text-muted-foreground">No drives scheduled today. 👋</p>
             </div>
          )}

          <div className="bg-gradient-to-br from-primary/5 to-transparent border border-primary/10 rounded-2xl p-6 mt-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-2 opacity-10">
              <Trophy className="w-12 h-12" />
            </div>
            <h3 className="font-bold text-lg mb-2">Invite Neighbors</h3>
            <p className="text-sm text-muted-foreground mb-4 leading-snug">
              Better cities start with better communities. Share the mission!
            </p>
            <Button variant="outline" className="w-full bg-background/50 backdrop-blur-sm border-primary/10 hover:bg-background shadow-sm text-xs font-bold">
              ✨ COPY INVITE LINK
            </Button>
          </div>
        </div>

      </div>
    </div>
  );
}
