import { useEvents } from "@/hooks/use-civic-data";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Calendar, MapPin, Clock, Users } from "lucide-react";
import { format } from "date-fns";

export default function Events() {
  const { data: events, isLoading } = useEvents();

  if (isLoading) return <div className="p-8 text-center text-muted-foreground">Loading events...</div>;

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="text-center mb-10">
        <h1 className="font-display font-bold text-3xl md:text-4xl mb-3">Community Drives</h1>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          Join your neighbors in making our city cleaner, safer, and more vibrant.
        </p>
      </div>

      <div className="space-y-6">
        {events?.map((event) => (
          <Card key={event.id} className="overflow-hidden hover:shadow-lg transition-all duration-300 border-border/60">
            <div className="flex flex-col md:flex-row">
              {/* Date Box */}
              <div className="bg-muted/30 md:w-48 p-6 flex flex-col items-center justify-center border-b md:border-b-0 md:border-r border-border/50 text-center">
                <span className="text-red-500 font-bold uppercase tracking-wider text-sm mb-1">
                  {format(new Date(event.startTime), "MMM")}
                </span>
                <span className="text-4xl font-display font-bold text-foreground">
                  {format(new Date(event.startTime), "d")}
                </span>
                <span className="text-muted-foreground text-sm mt-1">
                  {format(new Date(event.startTime), "EEEE")}
                </span>
              </div>
              
              {/* Content */}
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-display font-bold text-xl mb-2">{event.title}</h3>
                  <div className="flex flex-wrap gap-4 text-sm text-muted-foreground mb-4">
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-4 h-4" />
                      {format(new Date(event.startTime), "h:mm a")} - {format(new Date(event.endTime), "h:mm a")}
                    </div>
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-4 h-4" />
                      {event.location}
                    </div>
                  </div>
                  <p className="text-muted-foreground mb-6">
                    {event.description}
                  </p>
                </div>
                
                <div className="flex items-center justify-between pt-4 border-t border-border/30">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Users className="w-4 h-4" />
                    <span>24 people joining</span>
                  </div>
                  <Button>Join Event</Button>
                </div>
              </div>
            </div>
          </Card>
        ))}

        {events?.length === 0 && (
          <div className="text-center p-12 bg-muted/20 rounded-2xl border border-dashed border-border">
            <Calendar className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="font-semibold text-lg">No upcoming events</h3>
            <p className="text-muted-foreground">Check back later for community drives.</p>
          </div>
        )}
      </div>
    </div>
  );
}
