import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { ArrowRight, MapPin, CheckCircle, Gift, Users } from "lucide-react";
import { Link } from "wouter";

export default function Landing() {
  const { isLoading, isAuthenticated } = useAuth();

  if (isLoading) return null; // Or a loading spinner

  if (isAuthenticated) {
    window.location.href = "/dashboard";
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b border-border/40 backdrop-blur-md sticky top-0 z-50 bg-background/80">
        <div className="container mx-auto px-4 h-20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-primary to-secondary flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-primary/20">
              C
            </div>
            <span className="font-display font-bold text-2xl tracking-tight">CivicConnect</span>
          </div>
          <div className="flex gap-4">
            <a href="/api/login">
              <Button variant="ghost" className="font-semibold">Log In</Button>
            </a>
            <a href="/api/login">
              <Button className="font-semibold shadow-lg shadow-primary/25">
                Join Movement <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-20 pb-32 overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-background to-background"></div>
        <div className="container mx-auto px-4 text-center max-w-4xl">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-semibold mb-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
            </span>
            Empowering Citizens, Transforming Cities
          </div>
          
          <h1 className="font-display font-extrabold text-5xl md:text-7xl leading-[1.1] mb-8 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-100">
            Turn Your Civic Complaints Into <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">Real Change</span>
          </h1>
          
          <p className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto leading-relaxed animate-in fade-in slide-in-from-bottom-8 duration-700 delay-200">
            Report issues like potholes and garbage instantly. Our AI verifies your report, authorities fix it, and you earn rewards for being a responsible citizen.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-in fade-in slide-in-from-bottom-8 duration-700 delay-300">
            <a href="/api/login">
              <Button size="lg" className="h-14 px-8 text-lg rounded-2xl shadow-xl shadow-primary/20 hover:shadow-2xl hover:shadow-primary/30 hover:-translate-y-1 transition-all">
                Start Reporting
              </Button>
            </a>
            <Button variant="outline" size="lg" className="h-14 px-8 text-lg rounded-2xl border-2 hover:bg-muted/50">
              View Live Map
            </Button>
          </div>
        </div>
        
        {/* Placeholder for Hero Image */}
        <div className="container mx-auto px-4 mt-16 animate-in fade-in zoom-in duration-1000 delay-500">
          <div className="rounded-3xl overflow-hidden border border-border/50 shadow-2xl bg-muted aspect-video relative group">
            {/* Scenic cityscape or community action shot */}
            <img 
              src="https://images.unsplash.com/photo-1517048676732-d65bc937f952?w=1920&h=1080&fit=crop" 
              alt="Community working together" 
              className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent flex items-end justify-center pb-8">
              <p className="text-sm font-medium text-foreground/80">Join 10,000+ citizens making a difference</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="font-display font-bold text-3xl md:text-4xl mb-4">How It Works</h2>
            <p className="text-muted-foreground text-lg">CivicConnect bridges the gap between citizens and local authorities through technology and transparency.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: MapPin,
                title: "Report Issues",
                desc: "Snap a photo of potholes, garbage, or broken lights. We capture the location automatically.",
                color: "text-blue-500 bg-blue-500/10"
              },
              {
                icon: CheckCircle,
                title: "AI Verification",
                desc: "Our AI validates reports instantly to filter spam and prioritize urgent issues for authorities.",
                color: "text-green-500 bg-green-500/10"
              },
              {
                icon: Gift,
                title: "Earn Rewards",
                desc: "Get points for every verified report. Redeem them at local businesses and cafes.",
                color: "text-purple-500 bg-purple-500/10"
              }
            ].map((feature, i) => (
              <div key={i} className="bg-background p-8 rounded-3xl border border-border/50 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
                <div className={`w-14 h-14 rounded-2xl ${feature.color} flex items-center justify-center mb-6`}>
                  <feature.icon className="w-7 h-7" />
                </div>
                <h3 className="font-display font-bold text-xl mb-3">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">
                  {feature.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-border/40">
        <div className="container mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-white font-bold">C</div>
            <span className="font-display font-bold text-xl">CivicConnect</span>
          </div>
          <div className="text-sm text-muted-foreground">
            © 2024 CivicConnect. Building better cities together.
          </div>
        </div>
      </footer>
    </div>
  );
}
