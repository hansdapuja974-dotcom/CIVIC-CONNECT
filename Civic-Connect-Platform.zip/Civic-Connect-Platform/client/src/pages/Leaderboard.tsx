import { useLeaderboard } from "@/hooks/use-civic-data";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Trophy, Medal, Crown } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Leaderboard() {
  const { data: leaderboard, isLoading } = useLeaderboard();

  if (isLoading) return <div className="p-8 text-center text-muted-foreground">Loading leaderboard...</div>;

  const topThree = leaderboard?.slice(0, 3) || [];
  const rest = leaderboard?.slice(3) || [];

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="text-center mb-10">
        <h1 className="font-display font-bold text-4xl mb-2">Community Champions</h1>
        <p className="text-muted-foreground text-lg">Recognizing the heroes keeping our city clean.</p>
      </div>

      {/* Podium */}
      <div className="flex flex-col md:flex-row items-end justify-center gap-4 md:gap-8 mb-12 min-h-[240px]">
        {topThree[1] && (
          <div className="flex flex-col items-center order-2 md:order-1 animate-in slide-in-from-bottom-8 duration-700 delay-100">
            <Avatar className="w-20 h-20 border-4 border-slate-300 shadow-xl mb-4">
              <AvatarImage src={topThree[1].profileImageUrl || undefined} />
              <AvatarFallback className="text-xl font-bold bg-slate-100">{topThree[1].username?.[0]}</AvatarFallback>
            </Avatar>
            <div className="bg-slate-300 h-32 w-28 md:w-32 rounded-t-lg flex flex-col items-center justify-start pt-4 shadow-lg relative">
              <Medal className="w-8 h-8 text-slate-500 mb-1" />
              <span className="font-bold text-slate-700 text-xl">2</span>
            </div>
            <div className="mt-3 text-center">
              <p className="font-bold truncate max-w-[120px]">{topThree[1].firstName || topThree[1].username}</p>
              <p className="text-sm text-slate-500 font-medium">{topThree[1].points} pts</p>
            </div>
          </div>
        )}

        {topThree[0] && (
          <div className="flex flex-col items-center order-1 md:order-2 z-10 animate-in slide-in-from-bottom-8 duration-700">
            <div className="relative">
              <Crown className="w-10 h-10 text-yellow-500 absolute -top-8 left-1/2 -translate-x-1/2 animate-bounce" />
              <Avatar className="w-24 h-24 border-4 border-yellow-400 shadow-2xl mb-4 ring-4 ring-yellow-400/20">
                <AvatarImage src={topThree[0].profileImageUrl || undefined} />
                <AvatarFallback className="text-2xl font-bold bg-yellow-50">{topThree[0].username?.[0]}</AvatarFallback>
              </Avatar>
            </div>
            <div className="bg-gradient-to-b from-yellow-400 to-yellow-500 h-40 w-32 md:w-40 rounded-t-xl flex flex-col items-center justify-start pt-4 shadow-xl relative">
              <Trophy className="w-10 h-10 text-yellow-800 mb-1" />
              <span className="font-bold text-yellow-900 text-3xl">1</span>
            </div>
            <div className="mt-3 text-center">
              <p className="font-bold text-lg truncate max-w-[140px]">{topThree[0].firstName || topThree[0].username}</p>
              <p className="text-sm text-yellow-600 font-bold">{topThree[0].points} pts</p>
            </div>
          </div>
        )}

        {topThree[2] && (
          <div className="flex flex-col items-center order-3 animate-in slide-in-from-bottom-8 duration-700 delay-200">
            <Avatar className="w-20 h-20 border-4 border-amber-600 shadow-xl mb-4">
              <AvatarImage src={topThree[2].profileImageUrl || undefined} />
              <AvatarFallback className="text-xl font-bold bg-amber-50">{topThree[2].username?.[0]}</AvatarFallback>
            </Avatar>
            <div className="bg-amber-600 h-24 w-28 md:w-32 rounded-t-lg flex flex-col items-center justify-start pt-4 shadow-lg relative">
              <Medal className="w-8 h-8 text-amber-200 mb-1" />
              <span className="font-bold text-amber-100 text-xl">3</span>
            </div>
            <div className="mt-3 text-center">
              <p className="font-bold truncate max-w-[120px]">{topThree[2].firstName || topThree[2].username}</p>
              <p className="text-sm text-amber-700 font-medium">{topThree[2].points} pts</p>
            </div>
          </div>
        )}
      </div>

      {/* List for the rest */}
      <div className="bg-card border border-border/50 rounded-2xl shadow-sm overflow-hidden">
        {rest.length > 0 ? (
          rest.map((user, index) => (
            <div 
              key={user.userId} 
              className={cn(
                "flex items-center justify-between p-4 hover:bg-muted/50 transition-colors",
                index !== rest.length - 1 && "border-b border-border/50"
              )}
            >
              <div className="flex items-center gap-4">
                <span className="w-8 font-mono text-muted-foreground font-medium text-center">{index + 4}</span>
                <Avatar className="w-10 h-10 border border-border">
                  <AvatarImage src={user.profileImageUrl || undefined} />
                  <AvatarFallback>{user.username?.[0]}</AvatarFallback>
                </Avatar>
                <span className="font-medium">{user.firstName || user.username}</span>
              </div>
              <div className="font-mono font-semibold text-primary">{user.points} pts</div>
            </div>
          ))
        ) : (
          <div className="p-8 text-center text-muted-foreground">
            More citizens needed to fill the leaderboard!
          </div>
        )}
      </div>
    </div>
  );
}
