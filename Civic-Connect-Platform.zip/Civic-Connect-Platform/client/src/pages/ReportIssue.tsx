import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useCreateReport } from "@/hooks/use-civic-data";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card } from "@/components/ui/card";
import { Loader2, MapPin, Upload, X } from "lucide-react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";

// Schema for the form
const formSchema = z.object({
  title: z.string().min(5, "Title needs to be descriptive"),
  description: z.string().min(10, "Please provide more details"),
  latitude: z.string().or(z.number()),
  longitude: z.string().or(z.number()),
  mediaUrl: z.string().optional(),
});

export default function ReportIssue() {
  const [_, setLocation] = useLocation();
  const { mutate, isPending } = useCreateReport();
  const { toast } = useToast();
  const [locationLoading, setLocationLoading] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      latitude: "",
      longitude: "",
      mediaUrl: "https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?w=800&q=80", // Placeholder
    },
  });

  const getLocation = () => {
    setLocationLoading(true);
    setLocationError(null);
    if (!navigator.geolocation) {
      setLocationError("Geolocation is not supported by your browser");
      setLocationLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        form.setValue("latitude", position.coords.latitude);
        form.setValue("longitude", position.coords.longitude);
        setLocationLoading(false);
        toast({
          title: "Location Acquired",
          description: "Coordinates added to your report.",
        });
      },
      (error) => {
        setLocationError("Unable to retrieve your location");
        setLocationLoading(false);
      }
    );
  };

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    mutate({
      ...values,
      latitude: String(values.latitude),
      longitude: String(values.longitude),
    }, {
      onSuccess: () => {
        setLocation("/dashboard");
      }
    });
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h1 className="font-display font-bold text-3xl mb-2">Report an Issue</h1>
        <p className="text-muted-foreground">
          Help us improve the city by reporting infrastructure problems.
        </p>
      </div>

      <Card className="p-6 md:p-8 border-border shadow-md">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-semibold">Issue Title</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Deep pothole on Main St" className="h-12 text-lg" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-semibold">Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Describe the issue in detail..." 
                      className="min-h-[120px] resize-none text-base" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid sm:grid-cols-2 gap-6">
              {/* Location Input */}
              <div className="space-y-2">
                <FormLabel className="font-semibold">Location</FormLabel>
                <div className="border border-input rounded-xl bg-muted/20 p-4 flex flex-col items-center justify-center text-center gap-3 min-h-[120px]">
                  {form.watch("latitude") ? (
                    <div className="text-sm font-mono text-muted-foreground">
                      <div className="flex items-center gap-2 mb-1">
                        <MapPin className="w-4 h-4 text-primary" />
                        Lat: {Number(form.watch("latitude")).toFixed(6)}
                      </div>
                      <div>Long: {Number(form.watch("longitude")).toFixed(6)}</div>
                    </div>
                  ) : (
                    <div className="text-sm text-muted-foreground">
                      Location required
                    </div>
                  )}
                  
                  <Button 
                    type="button" 
                    variant="secondary" 
                    size="sm" 
                    onClick={getLocation}
                    disabled={locationLoading}
                  >
                    {locationLoading ? (
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    ) : (
                      <MapPin className="w-4 h-4 mr-2" />
                    )}
                    {form.watch("latitude") ? "Update Location" : "Get Current Location"}
                  </Button>
                  {locationError && <p className="text-xs text-destructive">{locationError}</p>}
                </div>
              </div>

              {/* Photo Upload (Mock) */}
              <div className="space-y-2">
                <FormLabel className="font-semibold">Evidence (Photo)</FormLabel>
                <div className="border border-dashed border-border rounded-xl bg-muted/10 hover:bg-muted/20 transition-colors p-4 flex flex-col items-center justify-center text-center gap-3 min-h-[120px] cursor-pointer group">
                  <div className="w-10 h-10 rounded-full bg-background border shadow-sm flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Upload className="w-5 h-5 text-muted-foreground" />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    <span className="font-semibold text-primary">Click to upload</span> or drag and drop
                  </p>
                  <p className="text-xs text-muted-foreground/60">Using placeholder image for demo</p>
                </div>
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full h-12 text-lg font-semibold shadow-lg shadow-primary/20 hover:shadow-primary/30"
              disabled={isPending || !form.watch("latitude")}
            >
              {isPending ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin mr-2" />
                  Submitting...
                </>
              ) : (
                "Submit Report"
              )}
            </Button>
          </form>
        </Form>
      </Card>
    </div>
  );
}
