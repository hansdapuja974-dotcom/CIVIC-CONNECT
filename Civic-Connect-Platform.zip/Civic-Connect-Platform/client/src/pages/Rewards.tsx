import { useRewards, useUserStats, useRedeemReward } from "@/hooks/use-civic-data";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, Coins, Tag } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function Rewards() {
  const { data: rewards, isLoading } = useRewards();
  const { data: stats } = useUserStats();
  const { mutate: redeem, isPending } = useRedeemReward();

  if (isLoading) return <div className="p-8 text-center"><Loader2 className="w-6 h-6 animate-spin mx-auto text-primary"/></div>;

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-end gap-4 border-b border-border/50 pb-6">
        <div>
          <h1 className="font-display font-bold text-3xl mb-2">Rewards Store</h1>
          <p className="text-muted-foreground">
            Exchange your Civic Points for exclusive offers.
          </p>
        </div>
        <div className="bg-primary/10 px-6 py-3 rounded-2xl border border-primary/20 flex items-center gap-3">
          <div className="bg-primary/20 p-2 rounded-full">
            <Coins className="w-6 h-6 text-primary" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground font-semibold uppercase">Your Balance</p>
            <p className="text-2xl font-display font-bold text-primary">{stats?.points || 0}</p>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {rewards?.map((reward) => (
          <Card key={reward.id} className="p-6 flex flex-col justify-between card-hover border-border/60">
            <div>
              <div className="bg-gradient-to-br from-secondary/20 to-secondary/5 w-12 h-12 rounded-xl flex items-center justify-center mb-4 text-secondary-foreground">
                <Tag className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-lg mb-1">{reward.title}</h3>
              <p className="text-sm font-semibold text-muted-foreground mb-3">{reward.businessName}</p>
              <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
                {reward.description}
              </p>
            </div>
            
            <div className="flex items-center justify-between pt-4 border-t border-border/50 mt-auto">
              <span className="font-bold text-primary text-lg">{reward.cost} pts</span>
              
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button 
                    variant={stats?.points && stats.points >= reward.cost ? "default" : "secondary"}
                    disabled={!stats?.points || stats.points < reward.cost || isPending}
                  >
                    Redeem
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Redeem Reward?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This will deduct <strong>{reward.cost} points</strong> from your balance.
                      You will receive a unique code to use at {reward.businessName}.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction 
                      onClick={() => redeem(reward.id)}
                      className="bg-primary hover:bg-primary/90"
                    >
                      Confirm Redemption
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
