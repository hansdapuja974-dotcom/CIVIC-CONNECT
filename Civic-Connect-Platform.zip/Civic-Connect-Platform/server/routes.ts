import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes, isAuthenticated } from "./replit_integrations/auth";
import { openai } from "./replit_integrations/audio/client"; // reusing client setup
import { batchProcess } from "./replit_integrations/batch"; // using batch process for robust AI calling

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Auth setup
  await setupAuth(app);
  registerAuthRoutes(app);

  // --- API Routes ---

  // Reports
  app.get(api.reports.list.path, async (req, res) => {
    const query = api.reports.list.input?.parse(req.query);
    const reports = await storage.getReports(query?.userId);
    // Simple in-memory filtering for status if needed, or pass to storage
    const filtered = query?.status 
      ? reports.filter(r => r.status === query.status)
      : reports;
    res.json(filtered);
  });

  app.get(api.reports.get.path, async (req, res) => {
    const report = await storage.getReport(Number(req.params.id));
    if (!report) return res.status(404).json({ message: "Report not found" });
    res.json(report);
  });

  app.post(api.reports.create.path, isAuthenticated, async (req, res) => {
    try {
      const input = api.reports.create.input.parse(req.body);
      const user = req.user as any;
      const userId = user.claims.sub;
      
      // Create initial report
      const report = await storage.createReport({
        ...input,
        userId,
      });

      // AI VERIFICATION PROCESS (Async)
      // We don't await this to keep response fast, or we could await if we want immediate feedback
      // For this demo, let's await it to show the "magic" immediately
      try {
        const aiResponse = await openai.chat.completions.create({
          model: "gpt-5.1",
          messages: [
            {
              role: "system",
              content: `You are an AI civic issue validator for a city governance app. 
              Analyze the report description. 
              1. Determine if it is a valid civic issue (pothole, garbage, broken street light, traffic violation, etc.).
              2. Categorize it.
              3. Assign a severity score (1-10).
              4. Return JSON: { "isValid": boolean, "category": string, "reason": string, "severity": number }`
            },
            {
              role: "user",
              content: `Title: ${input.title}\nDescription: ${input.description}`
            }
          ],
          response_format: { type: "json_object" }
        });

        const verification = JSON.parse(aiResponse.choices[0]?.message?.content || "{}");
        
        if (verification.isValid) {
          // Verify report and award points
          await storage.updateReport(report.id, {
            status: "in_progress", // Auto-move to in-progress if verified? or just 'submitted' but verified
            aiVerificationStatus: "verified",
            aiVerificationReason: `[AI Verified] ${verification.reason} (Severity: ${verification.severity}/10)`,
            pointsAwarded: 10 + (verification.severity || 0) // Base 10 + severity bonus
          });
          
          await storage.addPoints(userId, 10 + (verification.severity || 0), "report_verified", report.id);
        } else {
          await storage.updateReport(report.id, {
            aiVerificationStatus: "rejected",
            aiVerificationReason: `[AI Rejected] ${verification.reason}`,
            status: "rejected"
          });
        }
      } catch (err) {
        console.error("AI Verification failed:", err);
        // Fallback or leave as pending
      }

      const updatedReport = await storage.getReport(report.id);
      res.status(201).json(updatedReport);

    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  // Events
  app.get(api.events.list.path, async (req, res) => {
    const events = await storage.getEvents();
    res.json(events);
  });

  app.post(api.events.create.path, isAuthenticated, async (req, res) => {
    // Only allow some users? For now allow all authenticated
    const input = api.events.create.input.parse(req.body);
    const user = req.user as any;
    const event = await storage.createEvent({
      ...input,
      organizerId: user.claims.sub
    });
    res.status(201).json(event);
  });

  // Rewards
  app.get(api.rewards.list.path, async (req, res) => {
    const rewards = await storage.getRewards();
    res.json(rewards);
  });

  app.post(api.rewards.redeem.path, isAuthenticated, async (req, res) => {
    const rewardId = Number(req.params.id);
    const user = req.user as any;
    const userId = user.claims.sub;
    
    const reward = await storage.getReward(rewardId);
    if (!reward) return res.status(404).json({ message: "Reward not found" });

    const currentPoints = await storage.getUserPoints(userId);
    if (currentPoints < reward.cost) {
      return res.status(400).json({ message: "Insufficient points" });
    }

    // Deduct points
    await storage.addPoints(userId, -reward.cost, "redeemed", rewardId);
    const newBalance = await storage.getUserPoints(userId);
    
    res.json({ success: true, remainingPoints: newBalance });
  });

  // Leaderboard
  app.get(api.leaderboard.list.path, async (req, res) => {
    const leaderboard = await storage.getLeaderboard();
    res.json(leaderboard);
  });

  // User Me
  app.get(api.users.me.path, isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const userId = user.claims.sub;
    
    const points = await storage.getUserPoints(userId);
    const rank = await storage.getUserRank(userId);
    const reports = await storage.getReports(userId);
    
    res.json({
      points,
      rank,
      reportsCount: reports.length
    });
  });

  // Seed Data
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const rewards = await storage.getRewards();
  if (rewards.length === 0) {
    await storage.createReward({
      title: "Free Coffee",
      description: "Get a free cappuccino at City Cafe",
      cost: 100,
      businessName: "City Cafe"
    });
    await storage.createReward({
      title: "10% Off Groceries",
      description: "Discount on your next purchase",
      cost: 200,
      businessName: "Green Grocers"
    });
    await storage.createReward({
      title: "Cinema Ticket",
      description: "One free movie ticket",
      cost: 500,
      businessName: "Star Cinema"
    });
  }

  const events = await storage.getEvents();
  if (events.length === 0) {
    await storage.createEvent({
      organizerId: "system",
      title: "City Center Cleanup",
      description: "Join us to clean up the central park area.",
      location: "Central Park",
      startTime: new Date(Date.now() + 86400000), // Tomorrow
      endTime: new Date(Date.now() + 90000000),
    });
  }
}
