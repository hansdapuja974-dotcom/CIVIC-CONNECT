import { db } from "./db";
import { eq, desc, sql } from "drizzle-orm";
import { 
  reports, events, rewards, pointsHistory, users,
  type Report, type InsertReport, type UpdateReportRequest,
  type Event, type InsertEvent,
  type Reward, type InsertReward,
  type PointHistory, type User
} from "@shared/schema";
import { authStorage, type IAuthStorage } from "./replit_integrations/auth/storage";

export interface IStorage extends IAuthStorage {
  // Reports
  getReports(userId?: string): Promise<Report[]>;
  getReport(id: number): Promise<Report | undefined>;
  createReport(report: InsertReport): Promise<Report>;
  updateReport(id: number, updates: UpdateReportRequest): Promise<Report>;
  
  // Events
  getEvents(): Promise<Event[]>;
  createEvent(event: InsertEvent): Promise<Event>;
  
  // Rewards
  getRewards(): Promise<Reward[]>;
  getReward(id: number): Promise<Reward | undefined>;
  createReward(reward: InsertReward): Promise<Reward>;
  
  // Points
  getPointsHistory(userId: string): Promise<PointHistory[]>;
  addPoints(userId: string, amount: number, reason: string, relatedId?: number): Promise<PointHistory>;
  getUserPoints(userId: string): Promise<number>;
  
  // Leaderboard
  getLeaderboard(): Promise<any[]>;
  getUserRank(userId: string): Promise<number>;
}

export class DatabaseStorage implements IStorage {
  // Inherit Auth methods from the auth storage implementation
  // We delegate to the imported authStorage instance or re-implement
  async getUser(id: string): Promise<User | undefined> {
    return authStorage.getUser(id);
  }
  
  async upsertUser(user: any): Promise<User> {
    return authStorage.upsertUser(user);
  }

  // Reports
  async getReports(userId?: string): Promise<Report[]> {
    if (userId) {
      return db.select().from(reports).where(eq(reports.userId, userId)).orderBy(desc(reports.createdAt));
    }
    return db.select().from(reports).orderBy(desc(reports.createdAt));
  }

  async getReport(id: number): Promise<Report | undefined> {
    const [report] = await db.select().from(reports).where(eq(reports.id, id));
    return report;
  }

  async createReport(insertReport: InsertReport): Promise<Report> {
    const [report] = await db.insert(reports).values(insertReport).returning();
    return report;
  }

  async updateReport(id: number, updates: UpdateReportRequest): Promise<Report> {
    const [report] = await db.update(reports).set({ ...updates, updatedAt: new Date() }).where(eq(reports.id, id)).returning();
    return report;
  }

  // Events
  async getEvents(): Promise<Event[]> {
    return db.select().from(events).orderBy(desc(events.startTime));
  }

  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    const [event] = await db.insert(events).values(insertEvent).returning();
    return event;
  }

  // Rewards
  async getRewards(): Promise<Reward[]> {
    return db.select().from(rewards);
  }

  async getReward(id: number): Promise<Reward | undefined> {
    const [reward] = await db.select().from(rewards).where(eq(rewards.id, id));
    return reward;
  }

  async createReward(insertReward: InsertReward): Promise<Reward> {
    const [reward] = await db.insert(rewards).values(insertReward).returning();
    return reward;
  }

  // Points
  async getPointsHistory(userId: string): Promise<PointHistory[]> {
    return db.select().from(pointsHistory).where(eq(pointsHistory.userId, userId)).orderBy(desc(pointsHistory.createdAt));
  }

  async addPoints(userId: string, amount: number, reason: string, relatedId?: number): Promise<PointHistory> {
    const [history] = await db.insert(pointsHistory).values({
      userId,
      amount,
      reason,
      relatedId
    }).returning();
    return history;
  }

  async getUserPoints(userId: string): Promise<number> {
    const result = await db
      .select({ 
        total: sql<number>`sum(${pointsHistory.amount})` 
      })
      .from(pointsHistory)
      .where(eq(pointsHistory.userId, userId));
      
    return result[0]?.total || 0;
  }

  // Leaderboard
  async getLeaderboard(): Promise<any[]> {
    return db.select({
      userId: users.id,
      username: users.email, // using email as username fallback
      firstName: users.firstName,
      profileImageUrl: users.profileImageUrl,
      points: sql<number>`COALESCE(SUM(${pointsHistory.amount}), 0)`
    })
    .from(users)
    .leftJoin(pointsHistory, eq(users.id, pointsHistory.userId))
    .groupBy(users.id)
    .orderBy(desc(sql`COALESCE(SUM(${pointsHistory.amount}), 0)`))
    .limit(10);
  }

  async getUserRank(userId: string): Promise<number> {
    // Simple rank implementation: count how many users have more points
    const myPoints = await this.getUserPoints(userId);
    
    const result = await db.execute(sql`
      SELECT COUNT(*) as count FROM (
        SELECT user_id, SUM(amount) as total 
        FROM ${pointsHistory} 
        GROUP BY user_id
      ) as scores
      WHERE scores.total > ${myPoints}
    `);
    
    return Number(result.rows[0].count) + 1;
  }
}

export const storage = new DatabaseStorage();
