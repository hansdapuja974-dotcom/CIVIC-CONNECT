import { pgTable, text, serial, integer, boolean, timestamp, decimal, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Export Auth models
export * from "./models/auth";
export * from "./models/chat";

import { users } from "./models/auth";

// === REPORTS / ISSUES ===
export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(), // Links to auth.users.id
  title: text("title").notNull(),
  description: text("description").notNull(),
  latitude: text("latitude").notNull(), // Store as text to preserve precision or use double precision
  longitude: text("longitude").notNull(),
  mediaUrl: text("media_url"),
  status: text("status", { enum: ["submitted", "in_progress", "resolved", "rejected"] }).default("submitted").notNull(),
  aiVerificationStatus: text("ai_verification_status", { enum: ["pending", "verified", "rejected"] }).default("pending").notNull(),
  aiVerificationReason: text("ai_verification_reason"),
  pointsAwarded: integer("points_awarded").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertReportSchema = createInsertSchema(reports).omit({ 
  id: true, 
  userId: true, 
  status: true, 
  aiVerificationStatus: true, 
  aiVerificationReason: true, 
  pointsAwarded: true, 
  createdAt: true, 
  updatedAt: true 
}).extend({
  latitude: z.string().or(z.number().transform(String)),
  longitude: z.string().or(z.number().transform(String)),
});

// === EVENTS / DRIVES ===
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  organizerId: text("organizer_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  location: text("location").notNull(),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertEventSchema = createInsertSchema(events).omit({ id: true, organizerId: true, createdAt: true });

// === REWARDS ===
export const rewards = pgTable("rewards", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  cost: integer("cost").notNull(),
  businessName: text("business_name").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertRewardSchema = createInsertSchema(rewards).omit({ id: true, createdAt: true });

// === POINTS HISTORY ===
export const pointsHistory = pgTable("points_history", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  amount: integer("amount").notNull(),
  reason: text("reason").notNull(), // report_verified, drive_participation, redeemed
  relatedId: integer("related_id"), // report_id or event_id or reward_id
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// === RELATIONS ===
export const reportsRelations = relations(reports, ({ one }) => ({
  user: one(users, {
    fields: [reports.userId],
    references: [users.id],
  }),
}));

export const pointsHistoryRelations = relations(pointsHistory, ({ one }) => ({
  user: one(users, {
    fields: [pointsHistory.userId],
    references: [users.id],
  }),
}));

// === TYPES ===
export type Report = typeof reports.$inferSelect;
export type InsertReport = z.infer<typeof insertReportSchema>;
export type Event = typeof events.$inferSelect;
export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Reward = typeof rewards.$inferSelect;
export type PointHistory = typeof pointsHistory.$inferSelect;

// Request/Response Types
export type CreateReportRequest = InsertReport;
export type UpdateReportRequest = Partial<InsertReport> & { status?: string };
export type ReportResponse = Report & { user?: typeof users.$inferSelect };
